// import React from "react";

// const ContactSection = () => {
//   return (
//     <section className="py-16 px-4 sm:px-8 bg-[#f4f4f4]">

//       {/* Header */}
//       <div className="flex flex-col md:flex-row md:items-center gap-4 mb-12">
//         <span className="bg-lime-400 px-4 py-1 text-xl font-semibold rounded-md w-fit">
//           Contact Us
//         </span>
//         <p className="text-gray-600 text-sm">
//           Connect with Us: Let’s Discuss Your Digital Marketing Needs
//         </p>
//       </div>

//       {/* Form Container */}
//       <div className="bg-[#eaeaea] relative rounded-[30px] pl-8 md:pl-12 flex flex-col lg:flex-row gap-10 items-center justify-between">

//         {/* Left Side Form */}
//         <div className="w-full lg:w-1/2">

//           {/* Radio Buttons */}
//           <div className="flex gap-6 mb-6 text-sm">
//             <label className="flex items-center gap-2 cursor-pointer">
//               <input type="radio" name="type" defaultChecked className="accent-lime-400" />
//               Say Hi
//             </label>
//             <label className="flex items-center gap-2 cursor-pointer">
//               <input type="radio" name="type" className="accent-lime-400" />
//               Get a Quote
//             </label>
//           </div>

//           {/* Inputs */}
//           <div className="space-y-4">

//             <div>
//               <label className="text-sm">Name*</label>
//               <input
//                 type="text"
//                 placeholder="Name"
//                 className="w-full mt-1 px-4 py-3 rounded-xl border border-gray-400 bg-white focus:outline-none"
//               />
//             </div>

//             <div>
//               <label className="text-sm">Email*</label>
//               <input
//                 type="email"
//                 placeholder="Email"
//                 className="w-full mt-1 px-4 py-3 rounded-xl border border-gray-400 bg-white focus:outline-none"
//               />
//             </div>

//             <div>
//               <label className="text-sm">Message*</label>
//               <textarea
//                 rows="4"
//                 placeholder="Message"
//                 className="w-full mt-1 px-4 py-3 rounded-xl border border-gray-400 bg-white focus:outline-none"
//               />
//             </div>

//             <button className="w-full bg-[#111827] text-white py-3 rounded-xl mt-4">
//               Send Message
//             </button>

//           </div>
//         </div>

//         {/* Right Decorative Side */}
//         <div className="hidden absolute right-0 lg:flex w-1/2 justify-end items-center relative">
// {/* 
//           <div className="relative w-[300px] h-[300px]">

//             <div className="absolute inset-0 rounded-full border-[30px] border-transparent border-r-black rotate-45"></div>

//             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28 bg-black rotate-45"></div>

//             <div className="absolute bottom-10 left-10 w-12 h-12 bg-lime-400 rotate-45"></div> */}
//            <img src="https://i.postimg.cc/QdNzhMbk/contactus-removebg-preview.png" alt="" />
//           </div>

//         </div>

//       {/* </div> */}
//     </section>
//   );
// };

// export default ContactSection;

import React from "react";

const ContactSection = () => {
  return (
    <section className="py-16 px-4 sm:px-8 bg-[]">

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center gap-4 mb-12">
        <span className="bg-lime-400 md:text-4xl px-4 py-1 text-xl font-semibold rounded-md w-fit">
          Contact Us
        </span>
        <p className="text-gray-600 md:text-xl text-sm">
          Connect with Us: Let’s Discuss<br/> Your Digital Marketing Needs
        </p>
      </div>

      {/* Form Container */}
      <div className="relative bg-[#eaeaea] rounded-[30px] p-8 md:p-12 flex flex-col lg:flex-row gap-10 items-center overflow-hidden">

        {/* Left Side Form */}
        <div className="w-full lg:w-1/2">
          <div className="flex gap-6 mb-6 text-sm">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="type" defaultChecked className="accent-lime-400 md:text-xl" />
              Say Hi
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="type" className="accent-lime-400 md:text-xl" />
              Get a Quote
            </label>
          </div>

          {/* <div className="space-y-4">
            <div>
              <label className="text-sm text-left  self-start">Name*</label>
              <input
                type="text"
                placeholder="Name"
                className="w-full mt-1 px-4 py-3 rounded-xl border border-gray-400 bg-white"
              />
            </div>

            <div>
              <label className="text-sm">Email*</label>
              <input
                type="email"
                placeholder="Email"
                className="w-full mt-1 px-4 py-3 rounded-xl border border-gray-400 bg-white"
              />
            </div>

            <div>
              <label className="text-sm">Message*</label>
              <textarea
                rows="4"
                placeholder="Message"
                className="w-full mt-1 px-4 py-3 rounded-xl border border-gray-400 bg-white"
              />
            </div>

            <button className="w-full bg-[#111827] text-white py-3 rounded-xl mt-4">
              Send Message
            </button>
          </div> */}
          <div className="space-y-4">

  <div className="flex flex-col">
    <label className="block text-sm mb-1 text-left md:text-xl">
      Name*
    </label>
    <input
      type="text"
      placeholder="Name"
      className="w-full px-4 py-3 rounded-xl border border-gray-400 bg-white"
    />
  </div>

  <div className="flex flex-col">
    <label className="block text-sm mb-1 text-left md:text-xl">
      Email*
    </label>
    <input
      type="email"
      placeholder="Email"
      className="w-full px-4 py-4 rounded-xl border border-gray-400 bg-white"
    />
  </div>

  <div className="flex flex-col">
    <label className="block text-sm mb-1 text-left md:text-xl">
      Message*
    </label>
    <textarea
      rows="4"
      placeholder="Message"
      className="w-full px-4 py-6 rounded-xl border border-gray-400 bg-white"
    />
  </div>

  <button className="w-full md:text-2xl bg-[#111827] text-white py-3 rounded-xl mt-4">
    Send Message
  </button>

</div>
        </div>

        {/* Right Sticky Image */}
        <div className="hidden lg:flex  absolute right-10 bottom-0 h-full items-center">
          <img
            src="https://i.postimg.cc/QdNzhMbk/contactus-removebg-preview.png"
            alt="contact"
            className="max-w-[520px] h-[620px] translate-x-10"
          />
        </div>

      </div>

    </section>
  );
};

export default ContactSection;